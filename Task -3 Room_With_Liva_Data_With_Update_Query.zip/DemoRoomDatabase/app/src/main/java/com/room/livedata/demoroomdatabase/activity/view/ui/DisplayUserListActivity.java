package com.room.livedata.demoroomdatabase.activity.view.ui;

import android.annotation.SuppressLint;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.room.livedata.demoroomdatabase.R;
import com.room.livedata.demoroomdatabase.activity.database.UserDatabase;
import com.room.livedata.demoroomdatabase.activity.view.adapter.DisplayDataAdapter;
import com.room.livedata.demoroomdatabase.activity.view.callback.CallbackUser;
import com.room.livedata.demoroomdatabase.activity.service.model.UserModel;
import com.room.livedata.demoroomdatabase.activity.viewmodel.UserViewModel;
import com.room.livedata.demoroomdatabase.databinding.ActivityDisplayUserlistBinding;

import java.util.ArrayList;
import java.util.List;

public class DisplayUserListActivity extends AppCompatActivity implements CallbackUser{
    ActivityDisplayUserlistBinding mBinding;
    DisplayDataAdapter madapter;
    private UserViewModel mUserViewModel;
    private UserDatabase userDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_display_userlist);
        mBinding = DataBindingUtil.setContentView(this,R.layout.activity_display_userlist);
        //SetAdapterInRecyclerView
        setAdapterInRecylcerView();

        //InitializeViewModel
        initializeViewModel();
    }

    private void setAdapterInRecylcerView() {
        madapter = new DisplayDataAdapter(new ArrayList<UserModel>(),this);
        mBinding.showRecyclerViewList.setLayoutManager(new LinearLayoutManager(this));
        mBinding.showRecyclerViewList.setAdapter(madapter);
    }

    private void initializeViewModel() {
        userDatabase = UserDatabase.getDatabase(getApplicationContext());
        mUserViewModel = ViewModelProviders.of(this).get(UserViewModel.class);

        LiveData<List<UserModel>> userModel = userDatabase.userDao().getAllUsers();
        userModel.observe(DisplayUserListActivity.this, new Observer<List<UserModel>>() {
            @Override
            public void onChanged(@Nullable List<UserModel> userModels) {
                madapter.addUser(userModels);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.add_menu:
                Intent intent=new Intent(this,InsertDataActivity.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressLint("StringFormatMatches")
    @Override
    public void onDeleteUser(UserModel userModel) {
        mUserViewModel.deleteUser(userModel,userDatabase);
        Toast.makeText(this, getResources().getString(R.string.success,"Delete"), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpdateUser(UserModel userModel) {
        Intent updateIntent=new Intent(this,InsertDataActivity.class);
        updateIntent.putExtra(getResources().getString(R.string.modelobject),userModel);
        startActivity(updateIntent);
    }

}
