package com.room.livedata.demoroomdatabase.activity.view.callback;

import com.room.livedata.demoroomdatabase.activity.service.model.UserModel;

public interface CallbackUser {
    void onDeleteUser(UserModel userModel);
    void onUpdateUser(UserModel userModel);
}
