package com.room.livedata.demoroomdatabase.activity.view.ui;

import android.annotation.SuppressLint;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Toast;

import com.room.livedata.demoroomdatabase.R;
import com.room.livedata.demoroomdatabase.activity.database.UserDatabase;
import com.room.livedata.demoroomdatabase.activity.viewmodel.UserViewModel;
import com.room.livedata.demoroomdatabase.activity.service.model.UserModel;
import com.room.livedata.demoroomdatabase.databinding.ActivityInsertDataBinding;

public class InsertDataActivity extends AppCompatActivity {
    ActivityInsertDataBinding mBinding;
    private UserViewModel mUserViewModel;
    UserDatabase userDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_insert_data);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_insert_data);

        UserModel userModel=new UserModel();
        mBinding.setUser(userModel);

        //InitializeViewModel
        initializeViewModel();

        //Check model value is empty or not
        checkModelValueEmpty();
    }

    private void initializeViewModel() {
        userDatabase = UserDatabase.getDatabase(getApplicationContext());
        mUserViewModel = ViewModelProviders.of(this).get(UserViewModel.class);
    }

    private void checkModelValueEmpty() {
        UserModel userModel = (UserModel) getIntent().getSerializableExtra(getResources().getString(R.string.modelobject));
        if(userModel!=null) {
            mBinding.btnUpdateData.setVisibility(View.VISIBLE);
            mBinding.btnAddData.setVisibility(View.GONE);
            //Update Data
            onUpdateData(userModel);
        } else {
            onInsertData();
        }
    }

    private void onUpdateData(final UserModel userModel) {
        textChangeListener();
        mBinding.edtUsername.setEnabled(false);
        mBinding.getUser().setName(userModel.getName());
        mBinding.getUser().setAddress(userModel.getAddress());

        mBinding.btnUpdateData.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("StringFormatInvalid")
            @Override
            public void onClick(View view) {
                if (!validateData()) {
                }else {
                    mUserViewModel.UpdateUser(mBinding.getUser().getName(),mBinding.getUser().getAddress(), String.valueOf(userModel.getId()),userDatabase);
                    Toast.makeText(InsertDataActivity.this, getResources().getString(R.string.success,mBinding.btnUpdateData.getText().toString()), Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }

    private void textChangeListener() {
        mBinding.edtUsername.addTextChangedListener(new MyTextWatcher(mBinding.edtUsername));
        mBinding.edtAddress.addTextChangedListener(new MyTextWatcher(mBinding.edtAddress));
    }

    private void onInsertData() {
        textChangeListener();
        mBinding.btnAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!validateData()) {
                }else {
//                    UserModel user = new UserModel(mBinding.getUser().getName().toString(), mBinding.getUser().getAddress().toString());
                    //save the item before leaving the activity
                    mUserViewModel.addUser(mBinding.getUser(),userDatabase);
                    Toast.makeText(InsertDataActivity.this, getResources().getString(R.string.success,mBinding.btnAddData.getText().toString()), Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }

    private boolean validateData() {
        if (TextUtils.isEmpty(mBinding.edtUsername.getText().toString().trim())) {
            mBinding.textInputUsername.setError(getResources().getString(R.string.msg_enter, mBinding.textInputUsername.getHint().toString()));
            return false;
        }else
            mBinding.textInputUsername.setErrorEnabled(false);


        if (TextUtils.isEmpty(mBinding.edtAddress.getText().toString().trim())) {
            mBinding.textInputAddress.setError(getResources().getString(R.string.msg_enter, mBinding.textInputAddress.getHint().toString()));
            return false;
        }else
            mBinding.textInputAddress.setErrorEnabled(false);

        return true;
    }

    private class MyTextWatcher implements TextWatcher {

        private View view;

        private MyTextWatcher(View view) {
            this.view = view;
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        public void afterTextChanged(Editable editable) {
           validateData();
        }
    }
}
