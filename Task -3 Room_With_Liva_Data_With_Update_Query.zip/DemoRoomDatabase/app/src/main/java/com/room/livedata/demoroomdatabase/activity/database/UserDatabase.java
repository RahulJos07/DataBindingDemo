package com.room.livedata.demoroomdatabase.activity.database;

import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.migration.Migration;
import android.content.Context;
import android.support.annotation.NonNull;

import com.room.livedata.demoroomdatabase.activity.service.dao.UserDao;
import com.room.livedata.demoroomdatabase.activity.service.model.UserModel;

@Database(entities = UserModel.class,version = 2)
public abstract class UserDatabase extends RoomDatabase{

    private static UserDatabase INSTANCE;

    public static UserDatabase getDatabase(Context context){
        if(INSTANCE == null){
            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                    UserDatabase.class, "user_db")
                    .build();
        }
        return INSTANCE;
    }

    public static void destroyInstances(){
        INSTANCE = null;
    }

    public abstract UserDao userDao();

}

