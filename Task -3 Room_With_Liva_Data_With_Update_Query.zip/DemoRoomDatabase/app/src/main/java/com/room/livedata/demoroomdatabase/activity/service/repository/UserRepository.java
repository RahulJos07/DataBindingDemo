package com.room.livedata.demoroomdatabase.activity.service.repository;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;

import com.room.livedata.demoroomdatabase.activity.database.UserDatabase;
import com.room.livedata.demoroomdatabase.activity.service.dao.UserDao;
import com.room.livedata.demoroomdatabase.activity.service.model.UserModel;

import java.util.List;

public class UserRepository {
    private UserDao userDao;

    //Add User
    public void addUser(UserModel usermodel, UserDatabase userDatabase){
        new AddAsyncTask(userDatabase).execute(usermodel);
    }

    //Update
    public void UpdateUser(String name,String address,String id, UserDatabase userDatabase){
        new UpdateAsyncTask(userDatabase).execute(name,address,id);
    }

    //Delete User
    public void deleteUser(UserModel noteModel, UserDatabase userDatabase){
        new AddAsyncTask(userDatabase).execute(noteModel);
    }

    private static class AddAsyncTask extends AsyncTask<UserModel, Void, Void> {

        private UserDatabase db;

        public AddAsyncTask(UserDatabase userDatabase) {
            db = userDatabase;
        }

        @Override
        protected Void doInBackground(final UserModel... userModels) {
            db.userDao().insertUser(userModels[0]);
            //db.userDao().UpdateUser(userModels[0]);
            db.userDao().DeleteUser(userModels[0]);
            return null;
        }
    }

    private static class UpdateAsyncTask extends AsyncTask<Object, Void, Void> {

        private UserDatabase db;

        public UpdateAsyncTask(UserDatabase userDatabase) {
            db = userDatabase;
        }

        @Override
        protected Void doInBackground(Object... params) {
            String name= String.valueOf(params[0]);
            String address= String.valueOf(params[1]);
            String id= String.valueOf(params[2]);
            db.userDao().UpdateUser(name,address,id);
            return null;
        }
    }
}
