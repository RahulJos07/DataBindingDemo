package com.room.livedata.demoroomdatabase.activity.viewmodel;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.room.livedata.demoroomdatabase.activity.database.UserDatabase;
import com.room.livedata.demoroomdatabase.activity.service.repository.UserRepository;
import com.room.livedata.demoroomdatabase.activity.service.model.UserModel;

import java.util.List;

public class UserViewModel extends ViewModel{

    public void addUser(final UserModel usermodel, UserDatabase userDatabase){
        new UserRepository().addUser(usermodel,userDatabase);
    }

    public void UpdateUser(String name,String address,String id, UserDatabase userDatabase){
        new UserRepository().UpdateUser(name,address,id,userDatabase);
    }

    public void deleteUser(UserModel noteModel, UserDatabase userDatabase){
        new UserRepository().deleteUser(noteModel,userDatabase);
    }

}
